# Third-party components

- curl 8.23.0 · [upstream source](https://curl.se/download/curl-8.23.0.tar.xz)
- Mbed TLS 3.6.7 · [upstream source](https://github.com/Mbed-TLS/mbedtls/releases/tag/mbedtls-3.6.7)
- zlib 1.3.1 · [upstream source](https://zlib.net/fossils/zlib-1.3.1.tar.gz)
- Mozilla CA bundle dated 2026-11-05 · [certificate bundle and attribution](https://curl.se/docs/caextract.html)

The trust bundle is distributed under the [Mozilla Public License 2.0](https://mozilla.org/MPL/2.0/). The source data URL appears in the PEM file header.
